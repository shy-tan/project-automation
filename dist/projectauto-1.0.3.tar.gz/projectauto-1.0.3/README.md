A script for automating the steps from creating a new GitHub project and start writing code!

### TODO:

- make a package
